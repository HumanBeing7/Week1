#include <iostream>

int binarySearch(int arr[], int low, int high, int key, int& comparisons) {
    comparisons = 0;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        comparisons++;

        if (arr[mid] == key) {
            return mid; // Key found
        } else if (arr[mid] < key) {
            low = mid + 1; // Search in the right half
        } else {
            high = mid - 1; // Search in the left half
        }
    }

    return -1; // Key not found
}

int main() {
    const int maxSize = 100; // Assuming a maximum array size
    int inputArray[maxSize];
    int arraySize;

    // Input array size from the user
    std::cout << "Enter the size of the sorted array: ";
    std::cin >> arraySize;

    // Input sorted array elements from the user
    std::cout << "Enter the sorted elements of the array:\n";
    for (int i = 0; i < arraySize; ++i) {
        std::cout << "Element " << i + 1 << ": ";
        std::cin >> inputArray[i];
    }

    int searchKey;

    // Input search key from the user
    std::cout << "Enter the key to search: ";
    std::cin >> searchKey;

    int comparisons;
    int result = binarySearch(inputArray, 0, arraySize - 1, searchKey, comparisons);

    if (result != -1) {
        std::cout << searchKey << " is present at index " << result << " in the array." << std::endl;
    } else {
        std::cout << searchKey << " is not present in the array." << std::endl;
    }

    std::cout << "Total number of comparisons: " << comparisons << std::endl;

    return 0;
}