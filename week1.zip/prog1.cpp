
#include <iostream>

bool linearSearch(int arr[], int size, int key, int& comparisons) {
    comparisons = 0;
    for (int i = 0; i < size; ++i) {
        comparisons++;
        if (arr[i] == key) {
            return true;
        }
    }
    return false;
}

int main() {
    const int maxSize = 100; // Assuming a maximum array size
    int inputArray[maxSize];
    int arraySize;

    // Input array size from the user
    std::cout << "Enter the size of the array: ";
    std::cin >> arraySize;

    // Input array elements from the user
    std::cout << "Enter the elements of the array:\n";
    for (int i = 0; i < arraySize; ++i) {
        std::cout << "Element " << i + 1 << ": ";
        std::cin >> inputArray[i];
    }

    int searchKey;

    // Input search key from the user
    std::cout << "Enter the key to search: ";
    std::cin >> searchKey;

    int totalComparisons;
    bool result = linearSearch(inputArray, arraySize, searchKey, totalComparisons);

    if (result) {
        std::cout << searchKey << " is present in the array." << std::endl;
    } else {
        std::cout << searchKey << " is not present in the array." << std::endl;
    }

    std::cout << "Total number of comparisons: " << totalComparisons << std::endl;

    return 0;
}